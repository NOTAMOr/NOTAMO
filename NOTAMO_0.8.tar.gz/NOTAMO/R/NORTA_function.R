NORTA_function <- function(function_list,moments,acc=6,startval=NULL,alg="NLOPT_GN_CRS2_LM",maxeval=500){

  #prepare output
  out <- list()
  out$solution <- 0
  out$exp_moms <- matrix(0,nrow=dim(moments)[1],ncol=dim(moments)[2])
  out$exp_moms[,1] <- moments[,1]
  presp_fun <- function_list

  #set accuracy vector
  p <- seq(10^(-acc),1-10^(-acc),10^(-acc))

  #append accuracy vector to every function
  for (i in 1:length(function_list)){
    function_list[[i]]$p <- p
  }

  #handle starting values
  if (is.null(startval)) {
    startval <- rep(1,length(function_list)-1)/length(function_list)
  } else { #else check if starting values have correct size
    if(length(function_list)!=(length(startval)+1)) {
      if (length(function_list)==(length(startval))) {
        startval <- startval[1:(length(startval)-1)]/sum(startval)
      } else {
        stop('incorrect number of starting values')
      }
    }
  }

  #choose if root finding algorithm or nonlinear optimization is appropriate
  if (length(function_list)==(dim(moments)[1]+1)) {

    #define function that gets solved in multiroot
    function2solve0 <- function(x,params){
      functions <- params[[1]] #contains functions and parameters for function
      moments <- params[[2]]
      out <- rep(0,dim(moments)[1])
      for (i in 1:dim(moments)[1]){
        out[i] <- calc_std_mom(estimate_distr(x, function_list),moments[i,1])-moments[i,2]
      }
      return(out)
    }

    params <- list(function_list,moments)
    solution <- multiroot(function2solve0, startval, parms = params, maxiter = maxeval)
    # guarantee that weights add up to one
    scaled_sol <- solution$root/(sum(abs(solution$root))+abs(1-sum(solution$root)))

    for (i in 1:dim(moments)[1]) {
      out$exp_moms[i,2] <- calc_std_mom(estimate_distr(scaled_sol, function_list), moments[i,1])
    }
    out$ssd <- sum((out$exp_moms[,2]-moments[,2])^2)
    out$solution <- c(scaled_sol,1-sum(scaled_sol))

    if (out$ssd > 0.1) {
      warning(paste('Sum of squared differences between prespecified and expected moments is ',out$ssd,
                    '. Try different functions or starting values.',sep=""))
    }

  } else { #nloptr package handles cases with more functions/distributions than prespecified moments

    #define function that gets minimized in nloptr
    function2solve1 <- function(x){
      # output is sum of squared difference between target and generated moments
      out <- rep(0,dim(moments)[1])
      for (i in 1:dim(moments)[1]){
        out[i] <- calc_std_mom(estimate_distr(x, function_list), moments[i,1]) - moments[i,2]
      }
      return(sum(out^2))
    }

    # apply nonlinear minimization (to minimize absolute difference)
    solution <- nloptr(startval, function2solve1,opts=list(algorithm=alg,xtol_rel=.0001,maxeval=maxeval),
                       lb=rep(0,length(startval)),ub=rep(1,length(startval)))
    # guarantee that weights add up to one
    scaled_sol <- solution$solution/(sum(solution$solution)+abs(1-sum(solution$solution)))

    for (i in 1:dim(moments)[1]) {
      out$exp_moms[i,2] <- calc_std_mom(estimate_distr(scaled_sol, function_list), moments[i,1])
    }
    out$ssd <- sum((out$exp_moms[,2] - moments[,2])^2)
    out$solution <- c(scaled_sol,sum(scaled_sol))

    out$h <- solution

    if (out$ssd > 0.1) {
      warning(paste('Sum of squared differences between prespecified and expected moments is ',
                    out$ssd,'. Try different functions or starting values.',sep=""))
    }
  }
  out$presp_moms <- moments
  out$presp_funs <- presp_fun
  return(out)
}
