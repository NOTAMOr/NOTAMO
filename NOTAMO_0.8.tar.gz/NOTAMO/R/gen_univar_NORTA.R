gen_univar_NORTA <- function(NORTA_fun_out,N) {
  # takes the output of NORTA_function to generate a sample of size N, according to the prespecified functions and
  # moments
  p <- runif(N)
  #append uniform variable to function list
  for (i in 1:length(NORTA_fun_out$presp_funs)){
    NORTA_fun_out$presp_funs[[i]][[length(NORTA_fun_out$presp_funs[[i]])+1]] <- p
  }

  return(estimate_distr(NORTA_fun_out$solution[1:(length(NORTA_fun_out$solution)-1)],
                        NORTA_fun_out$presp_funs))
}
