prep_NORTA <- function(NORTA_fun_out,x) {
  y <- 0
  for (i in 1:length(NORTA_fun_out$solution)){
    args <- list(p=x)
    if (length(NORTA_fun_out$presp_funs[[i]])>1) {
      args <- append(args,NORTA_fun_out$presp_funs[[i]][[2:length(NORTA_fun_out$presp_funs[[i]])]])
      names(args[2:length(NORTA_fun_out$presp_funs[[i]])]) <-
        names(NORTA_fun_out$presp_funs[[i]][[2:length(NORTA_fun_out$presp_funs[[i]])]])
    }
    y <- y + NORTA_fun_out$solution[i]*do.call(NORTA_fun_out$presp_fun[[i]][[1]],args)
  }
  return(y)
}
