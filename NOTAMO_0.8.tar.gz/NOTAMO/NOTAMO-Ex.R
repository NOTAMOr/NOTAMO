pkgname <- "NOTAMO"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
options(pager = "console")
library('NOTAMO')

base::assign(".oldSearch", base::search(), pos = 'CheckExEnv')
cleanEx()
nameEx("NORTA_function")
### * NORTA_function

flush(stderr()); flush(stdout())

### Name: NORTA_function
### Title: Estimate NORTA function
### Aliases: NORTA_function

### ** Examples


### Example 1: Root-finding algorithm (number of CDFs = number of prespecified moments + 1):

# Define set of three inverse CDFs:
icdf_list <- list(
  list(qexp),
  list(qnormcube <- function(p) {
    return(qnorm(p)^3)
  }),
  list(qnorm)
)

# Define target moments:
moms <- matrix(0,nrow=2,ncol=2)
moms[1,] <- c(3,1)   #desired skewness is 1
moms[2,] <- c(4,10)  #desired kurtosis is 10

# Estimate parameters:
res1 <- NORTA_function(icdf_list,moms)

# Generate univariate sample from distribution with given moments and N=1000:
y <- gen_univar_NORTA(res1,1000)

# Calculate kurtosis of random variable
calc_std_mom(y,4)

### Example 2: Non-linear optimization (number of CDFs > number of prespecified moments + 1):

# Define set of four inverse CDFs:
icdf_list2 <- list(
  list(qexp),
  list(qnormcube <- function(p) {
    return(qnorm(p)^3)
  }),
  list(qexp,rate=2),
  list(qnorm)
)

# Estimate parameters:
res2 <- NORTA_function(icdf_list2,moms)

# Generate univariate sample from distribution with given moments and N=100:
gen_univar_NORTA(res2,100)

# The resulting distribution is different from the first example, despite having the same skewness and kurtosis.


### Example 3: Multivariate distribution

# Define correlation matrix:
target_cor <- matrix(0,nrow=2,ncol=2)
target_cor[1,] <- c(1,0.4)
target_cor[2,] <- c(0.4,1)

# Define functions for NORTARA:
f1 <- function(x) {
  return(prep_NORTA(res1,x))
}
f2 <- function(x) {
  return(prep_NORTA(res2,x))
}

# Generate bivariate distribution with prespecified correlation matrix, skewness, kurtosis, and N=100:
genNORTARA(100,target_cor,invcdfnames = c('f1','f2'),defaultindex=c(1,2))




cleanEx()
nameEx("calc_std_mom")
### * calc_std_mom

flush(stderr()); flush(stdout())

### Name: calc_std_mom
### Title: Calculate standardized central moments
### Aliases: calc_std_mom

### ** Examples

calc_std_mom(rnorm(1000),4)



### * <FOOTER>
###
options(digits = 7L)
base::cat("Time elapsed: ", proc.time() - base::get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
